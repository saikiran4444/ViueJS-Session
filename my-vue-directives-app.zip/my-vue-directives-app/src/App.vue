<template>
  <div>
    <!-- <directives/> -->
    <!-- <vfor-directive/> -->
    <!-- <state-city/> -->
    <todo/>
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'
import Directives from './components/Directives.vue'
import VforDirective from './components/VforDirective.vue'
import StateCity from './components/statescities.vue'
import Todo from './components/todolist.vue'

export default {
  name: 'app',
  components: {
    HelloWorld,
    Directives,
    VforDirective,
    StateCity,
    Todo
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
