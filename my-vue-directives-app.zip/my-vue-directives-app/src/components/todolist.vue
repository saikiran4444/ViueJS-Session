<template>
  <div>
    <input type="text" v-model="task" />
    <button @click="addTask()">Add</button>
    <ul>
      <li v-for="(t, a) in tasks">{{t}} <button @click="removeTask(a)">Remove</button></li>
    </ul>
  </div>
</template>


<script>
export default {
  name: "Todo",
  data() {
    return {
      task: "",
      tasks: []
    };
  },
  methods: {
    addTask() {
      this.tasks.push(this.task);
    },
    removeTask(index) {
        this.tasks.splice(index, 1);
    }
  }
};
</script>
