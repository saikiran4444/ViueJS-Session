<template>
    <div>
        <select v-model="state">
            <option value="ts">TS</option>
            <option value="ap">AP</option>
            <option value="tn">TN</option>
        </select>
        <div v-if="state == 'ap'">
            <select>
                <option v-for="c in ap_cities">{{c}}</option>
            </select>
        </div>
        <div v-else-if="state == 'tn'">
            <select>
                <option v-for="c in tn_cities">{{c}}</option>
            </select>
        </div>
        <div v-else-if="state == 'ts'">
            <select>
                <option v-for="c in ts_cities">{{c}}</option>
            </select>
        </div>
        <div v-else>
            select state
        </div>
        
    </div>
</template>


<script>
export default {
    name: 'StateCity',
    data() {
        return {
            ap_cities: ['vijayawad', 'guntur', 'nellor'],
            ts_cities: ['hyd', 'sec', 'wl'],
            tn_cities: ['chennai', 'kanchipuram', 'madhurai'],
            state: ''
        }
    }
}
</script>
