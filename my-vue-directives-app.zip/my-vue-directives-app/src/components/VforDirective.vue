<template>
    <div>
       <!-- 
        <ul>
            <li v-for="s in skills" :key="s">{{s}}</li>
        </ul>
        
        <select>
            <option v-for="s in skills">{{s}}</option>
        </select>

        
        <table border="1">
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Price</th>
            </tr>
            <tr v-for="p in products">
                <td>{{p.id}}</td>
                <td>{{p.name}}</td>
                <td>{{p.price}}</td>
            </tr>
        </table>-->
        <!-- v-model directive -->
        <input type="number" v-model="tickets"/><br/>
        <b>Total Price: {{tickets * 150}}</b>
    </div>
</template>


<script>
export default {
    name: 'VforDirective',
    data() {
        return {
            skills: ['java', 'pega', 'react', 'angular', 'node', 'mule'],
            products: [
                {id: 1, name: 'rice', price: 59},
                {id: 2, name: 'pen', price: 21},
                {id: 3, name: 'watch', price: 1299},
                {id: 4, name: 'pencil', price: 8}
            ],
            tickets: 0
        }
    }
}
</script>

