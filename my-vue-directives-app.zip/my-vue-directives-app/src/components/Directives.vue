<template>
    <div>
        {{message}}
        <p>{{city}}</p>
        <!-- v-bind directive -->
        <a v-bind:href="googleUrl">Click</a><br/>
        <a :href="tutorial">Tutorial</a>

        <!-- v-text directive -->
        <div v-text="course"></div>

        <!-- v-html directive -->
        <div v-text="wish"></div>
        <div v-html="wish"></div>

        <!-- v-if directive -->
        <div v-if="flag">Show if true</div>
        <div v-else>Show if false</div>
    </div>
    
</template>


<script>
export default {
    name: 'Directives',
    data() {
        return {
            message: 'hai',
            city: 'hyderabad',
            googleUrl: 'http://www.google.co.in',
            tutorial: 'http://www.w3schools.com',
            course: 'java',
            wish: '<b>hello, happy birthday</b>',
            flag: false
        }
    }
}
</script>

